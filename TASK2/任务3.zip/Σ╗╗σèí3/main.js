document.addEventListener("DOMContentLoaded",function(){
	var
},false);

//class选择器
function getClass(className,parent){
	var e[],
	    element = parent?document.getElementById('parent')||document;
    element = element.getElementByTagName("*");
    for(var i,len=element.length;i<len;i++){
    	if(className==element[i]){
    		e.push(element[i]);
    	}
    }
    return e;
}